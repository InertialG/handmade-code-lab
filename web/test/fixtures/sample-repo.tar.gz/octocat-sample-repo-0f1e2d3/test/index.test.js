const { main } = require('../src/index');
main([{ value: 1 }]);
