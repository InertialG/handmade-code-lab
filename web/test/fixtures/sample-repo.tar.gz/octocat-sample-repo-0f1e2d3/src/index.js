// 先这样，之后再重构
function main(data) {
  const result = process(data);
  console.log(result);
  return result;
}

function process(data) {
  try {
    return data.map((item) => item.value);
  } catch (e) {}
  return [];
}

module.exports = { main };
