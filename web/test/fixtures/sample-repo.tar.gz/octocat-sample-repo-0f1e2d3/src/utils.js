// TODO: 把这些搬走
function process2(data) {
  try {
    return data.map((item) => item.value);
  } catch (e) {}
  return [];
}

const temp_final = 1;
module.exports = { process2, temp_final };
